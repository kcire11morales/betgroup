package com.amadeus.betgroup;

import com.amadeus.betgroup.model.account.Credit;
import com.amadeus.betgroup.model.account.User;
import com.amadeus.betgroup.model.polla.PollaHeader;
import com.amadeus.betgroup.model.polla.PollaMatch;
import com.amadeus.betgroup.model.polla.PollaParticipant;
import com.amadeus.betgroup.model.tournament.Tournament;
import com.amadeus.betgroup.service.account.CreditService;
import com.amadeus.betgroup.service.account.UserService;
import com.amadeus.betgroup.service.polla.PollaHeaderService;
import com.amadeus.betgroup.service.polla.PollaMatchService;
import com.amadeus.betgroup.service.polla.PollaParticipantService;


import java.util.List;
import java.util.Scanner;

public class BetGroupTest {
    public static void main(String args[]) throws Exception{
        try{
            UserService userS = new UserService();
            User userBE;
            String username = null;
            String password = null;

            Scanner in = new Scanner(System.in);
            System.out.print("Please enter user name : ");
            username = in.nextLine();
            System.out.print("Please enter password :");
            password = in.nextLine();

            userBE = userS.validateLogin(username,  password);
            System.out.println( "Informacion de usuario " + userBE.getUsername());
            System.out.println( "userid = " + userBE.getUserId());
            System.out.println( "Name = " + userBE.getName());
            System.out.println( "email = " + userBE.getEmail());
            System.out.println( "*********************");

            CreditService creditS = new CreditService();
            Credit creditHistory = creditS.getCreditHistoryByUserId(userBE.getUserId());
            System.out.println( "Resumen de creditos para : " + userBE.getUsername() );
            System.out.println( "Total Creditos en cuenta = " + creditHistory.getTotalCreditos());
            System.out.println( "*********************");

            PollaHeaderService pollaHeaderS = new PollaHeaderService();
            List<PollaHeader> pollaHeaderList = pollaHeaderS.getPollaListByUserId( userBE.getUserId());

            System.out.println( "Listado de Pollas del usuario: " + userBE.getUsername());
            System.out.println( "Numero de pollas inscritas: " + pollaHeaderList.size());
            for (int i=0; i < pollaHeaderList.size(); i++ ){
                PollaHeader pollaHeader = pollaHeaderList.get(i);
                System.out.println( (i+1) + " #" + pollaHeader.getPollaName() + " - Entrada: " + pollaHeader.getPollaCost() + "  -  Acceso: " + pollaHeader.getAccessFlag());
            }
            System.out.println( "*********************");

            System.out.print("Seleccione id Polla a visualizar detalle: ");
            String spollaId = in.nextLine();
            Integer pollaId = Integer.parseInt(spollaId);

            System.out.println( "Detalles de polla :" + pollaHeaderList.get(pollaId-1).getPollaName());
            PollaParticipantService pollaParticipantS = new PollaParticipantService();
            List<PollaParticipant> participantList = pollaParticipantS.getParticipantsByPollaId(pollaHeaderList.get(pollaId-1).getPollaId());
            System.out.println( "# de participantes " + participantList.size());
            System.out.println( "Imprimiendo lista de participantes:");
            for (int i=0; i < participantList.size(); i++ ) {

                PollaParticipant participante = participantList.get(i);
                System.out.println( participante.getUser().getEmail() );
            }

            System.out.println( "*********************");
            System.out.print("Imprimiendo lista de partidos: ");
            PollaMatchService pollaMatchS = new PollaMatchService();
            List<PollaMatch> pollaMatchList = pollaMatchS.getParticipantsByPollaId(pollaHeaderList.get(pollaId-1).getPollaId());
            System.out.println( "# de partidos " + pollaMatchList.size());

           /*
            System.out.println( "Agregando un amigo con user name pedromc y user id 8,  al usuario chayno con userid 7");
            FriendService friendS = new FriendService();
            friendS.agregarAmigo(7,8);
            System.out.println( "Transaccion realizada correctamente.");
            */

        } catch( Exception e ){
            e.printStackTrace();
        }
    }
}
