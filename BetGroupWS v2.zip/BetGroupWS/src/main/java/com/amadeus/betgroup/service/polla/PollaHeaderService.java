package com.amadeus.betgroup.service.polla;

import com.amadeus.betgroup.dao.polla.PollaHeaderDAO;
import com.amadeus.betgroup.model.polla.PollaHeader;
import com.amadeus.betgroup.mybatis.MyBatisSqlSession;

import java.util.List;

public class PollaHeaderService {
    private PollaHeaderDAO pollaHeaderDAO = new PollaHeaderDAO(MyBatisSqlSession.getSqlSessionFactory());


    public List<PollaHeader> getPollaListByUserId(int userId) {
        List<PollaHeader> pollaList = pollaHeaderDAO.getPollaListByUserId(userId);

        return pollaList;
    }
}
