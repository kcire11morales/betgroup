package com.amadeus.betgroup.model.polla;

public class PollaBets {

}
