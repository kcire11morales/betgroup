package com.amadeus.betgroup.dao.account;

import com.amadeus.betgroup.model.account.Friend;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

public class FriendDAO {
    private SqlSessionFactory sqlSessionFactory;

    public FriendDAO(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }


    public void agregarAmigo(int userId , int amigoId) {

        SqlSession session = sqlSessionFactory.openSession();

        try {
            session.insert("Friend.agregarAmigo", userId);
            session.commit();
        } finally {
            session.close();
        }
    }
}
