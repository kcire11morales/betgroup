package com.amadeus.betgroup.dao.account;

import com.amadeus.betgroup.model.account.User;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

public class UserDAO {
    private SqlSessionFactory sqlSessionFactory;

    public UserDAO(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }


    public User validateLogin(String username, String password) {
        User user = new User();
        user.setUsername( username);
        user.setPassword( password );

        SqlSession session = sqlSessionFactory.openSession();

        try {
            user = session.selectOne("User.validateLogin", user);
        } finally {
            session.close();
        }

        return user;
    }
}
