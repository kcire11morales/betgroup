package com.amadeus.betgroup;

import com.amadeus.betgroup.model.account.Credit;
import com.amadeus.betgroup.model.account.User;
import com.amadeus.betgroup.service.account.CreditService;
import com.amadeus.betgroup.service.account.FriendService;
import com.amadeus.betgroup.service.account.UserService;

public class BetGroupTest {
    public static void main(String args[]) throws Exception{
        try{
            UserService userS = new UserService();
            User userBE;
            userBE = userS.validateLogin("kcire", "test1");
            System.out.println( "userid = " + userBE.getUserid());
            System.out.println( "Name = " + userBE.getName());
            System.out.println( "email = " + userBE.getEmail());

            System.out.println( "*********************");

            CreditService creditS = new CreditService();
            Credit creditHistory = creditS.getCreditHistoryByUserId(userBE.getUserid());
            System.out.println( "Getting total amount of creditos for user: " + userBE.getUsername() );
            System.out.println( "Total Creditos en cuenta = " + creditHistory.getTotalCreditos());

            System.out.println( "*********************");

           /*
            System.out.println( "Agregando un amigo con user name pedromc y user id 8,  al usuario chayno con userid 7");

            FriendService friendS = new FriendService();

            friendS.agregarAmigo(7,8);
            System.out.println( "Transaccion realizada correctamente.");
*/

        } catch( Exception e ){
            e.printStackTrace();
        }
    }
}
